# Lab #2 for Variable and expressions
#inputs
num1 = float(input("Enter the first number: \n")) #var num1
num2 = float(input("Enter the second number: \n")) #var num2   

# Process
sum = num1 + num2
difference = num1 - num2
product = num1 * num2
if num2 != 0:  # Check to avoid division by zero error
    quotient = num1 / num2
else:
    quotient = "undefined"  # Division by zero is not defined

# output
print("The sum of the numbers is:\n", sum)
print("The difference between the numbers is: \n", difference)
print("The product of the numbers is: \n", product)
print("The quotient of the numbers is: \n", quotient)