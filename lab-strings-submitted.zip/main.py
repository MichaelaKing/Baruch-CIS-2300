def version1_reverse(s):
        return s[::-1]
        
def version2_reverse(s):
    reverse= ""
    length=len(s)
    while (length>0):
        reverse += s[length-1]
        length=length-1
    return reverse
    
    
def main():

    word = input("Please enter a word to reverse: \n")
    print("The reverse string in version 1 is: ",version1_reverse(word))
    print("The reverse string in version 2 is: ",version2_reverse(word))
    
main()