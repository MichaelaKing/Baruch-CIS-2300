#Write a program that takes the age of a person as input. Based on the age, the program should categorize the person into different groups:

#If the age is less than 18, the person is categorized as a "minor".
#If the age is between 18 and 65 (inclusive), the person is categorized as an "adult".
#If the age is greater than 65, the person is categorized as a "senior citizen".
#Additionally, for adults (ages 18-65), if the age is exactly 21, the program should print a message "Happy 21st Birthday!" along with categorizing them as an adult.

#Submit your source code ( python file .py)

age = int(input("Please enter your age "))

if age < 18:
        Person = "Minor"
elif age >= 18 and age <= 65:
    Person = "adult"
elif age > 65:
    Person = "Senior citizen"
else: 
    Person = "Please enter a valid number"

if age == 21:
    print(" The Persons age is",age,"\n The person is an", Person, "\nHappy 21st Birthday!")
else: 
    print(" The Persons age is", age,"\n The person is an", Person)
    