#input

age = int(input("Please enter your age "))
bill = float(input("Please enter your bill total $"))

if age < 40:
        if bill < 50:
            tip = .15
        elif bill >= 50 and bill <= 100:
            tip = .20 
        elif bill > 100:
            tip = .25
        else:
            print("Please enter a valid number")
elif age >= 40 and age <= 60:
        if bill < 50:
            tip = .10
        elif bill >= 50 and bill <=100:
            tip = .15
        elif bill > 100:
            tip = .20
elif age > 60:
        if bill < 50:
            tip = .0
        elif bill >= 50 and bill <=100:
            tip = .05
        elif bill > 100:
            tip = .10

totaltip = bill * tip
    
totalbill = bill + totaltip

print("Yor bill is \n$"+ str(bill),"\nYour tip is \n$"+ str(totaltip), "\nYour Total for your meal is \n$" + str(totalbill))


        