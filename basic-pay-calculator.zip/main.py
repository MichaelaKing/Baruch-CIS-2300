#Michaela Assignment Number #2

#Inputs 

pay_rate = float(input("Please enter your pay rate: " ))
time_worked = float (input("Please input your time worked: "))

#Process 
total_pay =  pay_rate * time_worked
deduction =  total_pay * .25
net_pay =  total_pay - deduction


#Outputs
print("\nTotal pay is ", total_pay, "\nThe total deduction at 25% is ", deduction, "\nYour net pay is ", net_pay)