

temp = int(input("Enter the Tempurature: \n" ))

if temp < 40 :
    print("A little cold")
else:
    print("Nice weather")
    print("No need for a jacket")
    
    