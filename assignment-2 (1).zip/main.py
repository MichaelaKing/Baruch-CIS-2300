# Assignment #2 for Variable and expressions
#inputs
wage = float(input("Enter your hourly wage: \n$")) #var wage
hours = float(input("Enter your hours: \n")) #var hours
overtimehours = float(input("Enter your overtime hours: \n")) #var overtime hours

# Process
 
overtimepay = overtimehours * 1.5 * wage #figure out the overtime pay
weeklypay = (wage * hours) + overtimepay #figure out weekly pay

# output
print("The total weekly pay is:\n$", weeklypay)

