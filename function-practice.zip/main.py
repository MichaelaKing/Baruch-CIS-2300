def calculate(unt,quantity):
    return unit*quantity
    
def main():
    unit_price=int(input("Enter the unit price: \n"))
    quantity = int(input("Enter the quantity: \n"))
    print("The total price is : $"+str(calculate(unit_price,quantity)))
    
main()