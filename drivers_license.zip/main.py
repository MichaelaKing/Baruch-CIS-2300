"""Objective: create a program that determines whether a person is eligible for a driver's license based on age and a driving test score:

Create a program named "driver_license.py" that takes as inputs the person's age driving test score (out of 100).

The program should use a function named check_license_eligibility to make the determination. Here are the eligibility criteria:

If the person is 18 years or older and has a driving test score of 70 or higher, they are eligible for a driver's license.
Otherwise, the person is not eligible for a driver's license.
Your program should use the main function to test the function check_license_eligibility and print a message indicating whether the person is eligible or not."""


# Function to check license eligibility
def check_license_eligibility(age, score):
    if score > 100:
        return "Invalid score. The score must be between 0 and 100."
    elif age >= 18 and score >= 70:
        return True
    else:
        return False

def main():

#input from the user 
    age = int(input("Enter the person's age: "))
    score = int(input("Enter the driving test score (out of 100): "))
   
   
    # Output to Check eligibility
  
    if check_license_eligibility(age, score):
        print("Congrats you are eligible for for a driver's license.")
    else:
        print("Sorry you failed and are not eligible for a driver's license.")
        
main()
