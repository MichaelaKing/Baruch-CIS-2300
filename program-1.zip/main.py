""" a) The program i believe is calculating a factorial number that if its given a positive number it will give the user the product of all the intergers"""
""" b) I believe there is another way to write this program """
""" c) The other way would be using the import math function in pythons built in library.The math function might be better for efficientcy reasons however i am following the flow chart in this isinstance """


def factorial(n):
    
        if n <= 0:
          return "Error"
        else:
            Fact = 1
            while n > 1:
                Fact = Fact * n
                n = n-1
            return Fact 
            
def main():


    n = int(input("Enter a positive number for N: \n"))
    print("The factorial number for N is: ", factorial(n))
main()
