import math
number_of_prices = 0
total_prices = 0

price = float(input("Enter the price:\n"))
while price >= 0:
    number_of_prices=number_of_prices+1 
    total_prices=total_prices+price
    price = float(input("Enter the price:\n"))

if number_of_prices > 0:
    average = total_prices/number_of_prices
    average=round(average,2)
    print("The average is "+str(average))
else:
    print("No stock prices entered!")