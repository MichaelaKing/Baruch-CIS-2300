# Void Function

#Function Definition 
def add(a, b):
    result = a + b
    return result
 
 #Function call
def main():
    num1 = int(input("Enter Number 1: \n"))
    num2 = int(input("Enter Number 2: \n"))
    print("The Sum is: ", add(num1,num2)) #num1 and num2 are arguments
    
main()
