#Exam 1 Review Program 

#input

weight = float(input("Please Enter the weight of the item: \n"))
shiptype = input("Please enter the type of shipping you would like.\nRegular or Overnight?: \n")

regular = 0
overnight = 0

#process of shipping costs

if weight < 5:
    regular = 7
    overnight = 15 
elif weight >=5 and weight <=10:
    regular = 14
    overnight = 25
elif weight > 10:
    regular = 20
    overnight = 40
else:
     print("Please enter a valid weight")
    
    
#output

if shiptype == "Regular" or shiptype == "regular":
    print("Regular shipping for this item it will be \n$",regular)
elif shiptype == "Overnight" or shiptype == "overnight": 
    print("To ship this item overnight it will be \n$",overnight)
else:
    print("Please enter a valid form of shipment")
    
