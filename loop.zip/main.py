#Write a program that asks the user repeatedly if he/she wants to enter another score yes/no.
#When finished entering all the scores, the program should display the number of scores entered,
#the sum of the scores, the mean, the lowest, and the highest score. 
#The program also should display an error message if the user enters a score less than 0 or more than 100 
#(You can't use lists or predefined functions for this assignment).


#declaration of variables being used in the program 
another_score = 'yes'
number_of_scores = 0
sum_of_scores = 0
lowest_score = 101
highest_score = -1

#loop to continue asking the user whether or not they want to add another score and 
#determine what the highest and lowest scores will be
while another_score == 'yes':
    score = float(input("Enter a score:\n"))
    if 0 <= score <= 100:
        sum_of_scores += score #sum of the scores
        number_of_scores += 1
        if score < lowest_score: 
            lowest_score = score #finding the lowest score
        if score > highest_score:
            highest_score = score #finding the lowest score
    else:
        print("Error: Score {score} is invalid. Score must be between 0 and 100.") #error messege 
    another_score = input("Do you want to enter another score? Type yes or no:\n") #determining  if the loop should end or continue

#output of the number of scores added, sum, mean, highest score, and lowest score
if number_of_scores > 0:
    mean = sum_of_scores / number_of_scores
    print("The number of scores you input was:", number_of_scores)
    print("The sum of your scores is:", sum_of_scores)
    print("The mean of your scores is:", mean)
    print("The lowest score was:", lowest_score)
    print("The highest score was:", highest_score)
else:
    print("No valid scores were entered.")