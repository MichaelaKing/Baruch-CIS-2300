#Guessing Game

import random


#input of the guessed number and declaration of the secret number and number of tries

secret_number = random.randint(1,100)
tries = 0
num_guessed = int(input("Guess a random number between 1 and 100 "))

#Process Generate a random number from 1 to 100
while num_guessed!=secret_number:
    if (num_guessed>secret_number):
        print("Too high enter a smaller number\n")
    if (num_guessed<secret_number):
        print("Too low, enter a larger number\n")
        
    tries = tries+1
    num_guessed = int(input("Guess a number between 1 and 100:\n"))
    
#Output of the correct number and the number of tries

print("You guessed the correct number! The secret number is:",num_guessed)
print("\nIt took you",tries,"tries to guess the number ")        