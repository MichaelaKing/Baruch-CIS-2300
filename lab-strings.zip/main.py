# Taking input from the user
input_string = input("Enter a string: ")
# Reversing the string using slicing and printing the result
reversed_string = input_string[::-1]
print("Reversed string:", reversed_string)



#Using Loops
# Taking input from the user
input_string = input("Enter a string: ")
reversed_string = ""

# Loop directly over the string in reverse order
for character in reversed(input_string):
    reversed_string += character

# Printing the reversed string
print("Reversed string:", reversed_string)